#Luis Johan Galvez Lezama
#Incidencias del sistema de todas las empresas durante una semana
import statistics
data = [4, 0, 2, 5, 1, 3, 4]
print(statistics.mean(data))
print(statistics.median(data))
print(statistics.median_low(data))
print(statistics.median_high(data))
print(statistics.mode(data))
print(statistics.pstdev(data))
print(statistics.pvariance(data))
mu = statistics.mean(data)
print(statistics.pvariance(data, mu))
m = statistics.mean(data)
print(statistics.variance(data, m))

